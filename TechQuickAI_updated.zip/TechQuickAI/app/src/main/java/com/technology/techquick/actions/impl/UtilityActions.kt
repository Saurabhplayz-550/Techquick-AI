package com.technology.techquick.actions.impl

import android.content.Context
import android.content.Intent
import android.provider.MediaStore
import android.provider.Settings
import com.technology.techquick.model.ActionResult

class UtilityActions(private val context: Context) {

    fun openCalculator(): ActionResult = try {
        val intent = Intent(Intent.ACTION_MAIN).apply {
            addCategory(Intent.CATEGORY_APP_CALCULATOR)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        context.startActivity(intent)
        ActionResult.Success("Opening the calculator.")
    } catch (e: Exception) {
        ActionResult.Failure("Couldn't find a calculator app on this device.")
    }

    fun openSettings(): ActionResult = try {
        context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ActionResult.Success("Opening Settings.")
    } catch (e: Exception) {
        ActionResult.Failure("Couldn't open Settings.")
    }

    fun openCamera(): ActionResult = try {
        context.startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        ActionResult.Success("Opening the camera.")
    } catch (e: Exception) {
        ActionResult.Failure("Couldn't open the camera.")
    }

    fun openGallery(): ActionResult = try {
        val intent = Intent(Intent.ACTION_VIEW, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        ActionResult.Success("Opening the gallery.")
    } catch (e: Exception) {
        ActionResult.Failure("Couldn't open the gallery.")
    }
}
