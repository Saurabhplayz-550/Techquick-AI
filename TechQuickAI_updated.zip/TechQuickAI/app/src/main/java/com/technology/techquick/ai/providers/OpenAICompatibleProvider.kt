package com.technology.techquick.ai.providers

import com.technology.techquick.ai.AIProvider
import com.technology.techquick.ai.HttpClientProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/**
 * Handles OpenAI itself AND every "OpenAI-compatible" free/cheap provider
 * (Groq, OpenRouter, Together AI, Mistral, Fireworks, DeepSeek, local
 * Ollama servers, etc.) since they all speak the same
 * /chat/completions wire format. Only the base URL, model name and key
 * differ, which is exactly what the user supplies in onboarding.
 */
class OpenAICompatibleProvider : AIProvider {

    private val json = "application/json; charset=utf-8".toMediaType()

    private fun buildBody(systemPrompt: String, history: List<Pair<Boolean, String>>, userMessage: String, model: String): String {
        val messages = JSONArray()
        messages.put(JSONObject().put("role", "system").put("content", systemPrompt))
        history.forEach { (isUser, text) ->
            messages.put(JSONObject().put("role", if (isUser) "user" else "assistant").put("content", text))
        }
        messages.put(JSONObject().put("role", "user").put("content", userMessage))

        return JSONObject()
            .put("model", model)
            .put("messages", messages)
            .put("temperature", 0.4)
            .toString()
    }

    override suspend fun sendMessage(
        systemPrompt: String,
        history: List<Pair<Boolean, String>>,
        userMessage: String,
        apiKey: String,
        baseUrl: String,
        model: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val url = "${baseUrl.trimEnd('/')}/chat/completions"
            val body = buildBody(systemPrompt, history, userMessage, model).toRequestBody(json)
            val request = Request.Builder()
                .url(url)
                .addHeader("Authorization", "Bearer $apiKey")
                .addHeader("Content-Type", "application/json")
                .post(body)
                .build()

            HttpClientProvider.client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Provider error ${response.code}: ${bodyStr.take(200)}"))
                }
                val content = JSONObject(bodyStr)
                    .getJSONArray("choices")
                    .getJSONObject(0)
                    .getJSONObject("message")
                    .getString("content")
                Result.success(content)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun testConnection(apiKey: String, baseUrl: String, model: String): Result<Unit> =
        sendMessage(
            systemPrompt = "You are a connection test. Reply with the single word OK.",
            history = emptyList(),
            userMessage = "ping",
            apiKey = apiKey,
            baseUrl = baseUrl,
            model = model
        ).map { }
}
