package com.technology.techquick.actions.impl

import android.content.Context
import android.content.Intent
import android.provider.Settings
import com.technology.techquick.accessibility.TechQuickAccessibilityService
import com.technology.techquick.model.ActionResult

/**
 * Screen reading and on-screen tapping, backed by [TechQuickAccessibilityService].
 * Requires the user to have turned that service on once from Android's own
 * Accessibility settings — no app, including this one, can enable it silently.
 */
class ScreenActions(private val context: Context) {

    fun readScreen(): ActionResult {
        if (!TechQuickAccessibilityService.isEnabled()) return notEnabled()
        val text = TechQuickAccessibilityService.readScreen()
        return if (text.isNullOrBlank())
            ActionResult.Failure("I couldn't find any readable text on the screen right now.")
        else
            ActionResult.Success(text, text)
    }

    fun clickElement(label: String): ActionResult {
        if (label.isBlank()) return ActionResult.Failure("Tell me what to click on.")
        if (!TechQuickAccessibilityService.isEnabled()) return notEnabled()
        return if (TechQuickAccessibilityService.clickByLabel(label))
            ActionResult.Success("Tapped \"$label\".")
        else
            ActionResult.Failure("I couldn't find \"$label\" on the screen.")
    }

    fun accessibilitySettingsIntent(): Intent =
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

    private fun notEnabled() = ActionResult.Failure(
        "Turn on TechQuick's Accessibility permission in Settings first — I need it to see and tap the screen."
    )
}
