package com.technology.techquick.actions.impl

import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.os.Build
import com.technology.techquick.device.TechQuickDeviceAdminReceiver
import com.technology.techquick.model.ActionResult
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class DeviceActions(private val context: Context) {

    private val audioManager by lazy { context.getSystemService(Context.AUDIO_SERVICE) as AudioManager }
    private val cameraManager by lazy { context.getSystemService(Context.CAMERA_SERVICE) as CameraManager }
    private val devicePolicyManager by lazy {
        context.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
    }
    private val adminComponent by lazy { ComponentName(context, TechQuickDeviceAdminReceiver::class.java) }

    fun setVolume(percentage: Int): ActionResult {
        val clamped = percentage.coerceIn(0, 100)
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val target = (max * clamped / 100.0).toInt()
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, target, 0)
        return ActionResult.Success("Media volume set to $clamped%.", "$clamped%")
    }

    fun adjustVolume(amountPercent: Int, raise: Boolean): ActionResult {
        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
        val step = (max * amountPercent / 100.0).toInt().coerceAtLeast(1)
        val newVal = if (raise) (current + step).coerceAtMost(max) else (current - step).coerceAtLeast(0)
        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVal, 0)
        val percent = (newVal * 100.0 / max).toInt()
        return ActionResult.Success(
            if (raise) "Volume increased to $percent%." else "Volume decreased to $percent%.",
            "$percent%"
        )
    }

    fun setFlashlight(on: Boolean): ActionResult {
        return try {
            val cameraId = cameraManager.cameraIdList.firstOrNull { id ->
                cameraManager.getCameraCharacteristics(id)
                    .get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return ActionResult.Failure("This device doesn't have a flashlight.")
            cameraManager.setTorchMode(cameraId, on)
            ActionResult.Success(if (on) "Flashlight turned on." else "Flashlight turned off.", if (on) "ON" else "OFF")
        } catch (e: Exception) {
            ActionResult.Failure("Couldn't control the flashlight: ${e.message}")
        }
    }

    fun getTime(): ActionResult {
        val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
        return ActionResult.Success("It's ${fmt.format(Date())}.", fmt.format(Date()))
    }

    fun getDate(): ActionResult {
        val fmt = SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault())
        return ActionResult.Success("Today is ${fmt.format(Date())}.", fmt.format(Date()))
    }

    fun isDeviceAdminActive(): Boolean = devicePolicyManager.isAdminActive(adminComponent)

    /** Intent to send the user to the system screen where they grant the force-lock admin permission. */
    fun requestDeviceAdminIntent(): android.content.Intent =
        android.content.Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN).apply {
            putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, adminComponent)
            putExtra(
                DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "TechQuick needs this so voice commands like \"shut down my phone\" can lock the screen instantly."
            )
        }

    /**
     * True device power-off isn't something a regular (non-root, non-system)
     * app can do on stock Android — SHUTDOWN is a protected, system-only
     * permission. Force-locking the screen immediately is the closest and
     * only legitimate equivalent available to us, so that's what "shut down
     * my phone" / "turn off my phone" map to.
     */
    fun lockDevice(): ActionResult {
        if (!isDeviceAdminActive()) {
            return ActionResult.Failure(
                "I can't fully power off the phone — Android doesn't allow that for regular apps, only the screen lock. " +
                    "To enable that, grant TechQuick the device admin permission once from Settings."
            )
        }
        return try {
            devicePolicyManager.lockNow()
            ActionResult.Success("Locking the screen now.")
        } catch (e: SecurityException) {
            ActionResult.Failure("I don't have permission to lock the screen yet.")
        } catch (e: Exception) {
            ActionResult.Failure("Couldn't lock the screen: ${e.message}")
        }
    }
}
