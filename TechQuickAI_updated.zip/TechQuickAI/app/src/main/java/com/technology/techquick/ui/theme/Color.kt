package com.technology.techquick.ui.theme

import androidx.compose.ui.graphics.Color

// TechQuick brand palette: blue + cyan core, subtle purple accents.
val TQBlue = Color(0xFF3E7BFA)
val TQBluePale = Color(0xFFDCE8FF)
val TQCyan = Color(0xFF22D3EE)
val TQPurple = Color(0xFF8B5CF6)

val TQLightBackground = Color(0xFFF7F9FC)
val TQLightSurface = Color(0xFFFFFFFF)
val TQLightOnSurface = Color(0xFF15181F)
val TQLightOnSurfaceMuted = Color(0xFF6B7280)

val TQDarkBackground = Color(0xFF0B0E14)
val TQDarkSurface = Color(0xFF141821)
val TQDarkOnSurface = Color(0xFFEAEFFB)
val TQDarkOnSurfaceMuted = Color(0xFF9AA4B8)

val TQSuccess = Color(0xFF22C55E)
val TQError = Color(0xFFEF4444)

// --- Fixed HUD console palette -------------------------------------------
// The Home screen is a sci-fi control console, not a themeable Material
// surface: it looks the same regardless of the user's light/dark setting,
// exactly like the reference design. Every Home-tree composable (AIOrb,
// HudBackground, HudWidgetCard, InputBar, ActionCardView, HomeScreen itself)
// pulls colors from here instead of MaterialTheme.colorScheme. Settings,
// onboarding, memory, and personality screens are unaffected and keep
// following the normal light/dark theme.
val HudInkTop = Color(0xFF020A0F)
val HudInkBottom = Color(0xFF06141B)
val HudPanelFill = Color(0xFF071B23)
val HudCyan = Color(0xFF00E5FF)
val HudCyanBright = Color(0xFF47F4FF)
val HudBlue = Color(0xFF18AFFF)
val HudCyanDim = Color(0xFF16899A)
val HudTextBright = Color(0xFFE9FDFF)
val HudTextMuted = Color(0xFF72929A)
val HudAlertRed = Color(0xFFFF3B5C)
