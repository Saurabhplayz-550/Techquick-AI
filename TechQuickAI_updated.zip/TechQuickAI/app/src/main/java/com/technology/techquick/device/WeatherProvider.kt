package com.technology.techquick.device

import com.technology.techquick.ai.HttpClientProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import org.json.JSONObject

/**
 * Open-Meteo (open-meteo.com) needs no API key/signup, unlike most weather
 * providers — a perfect fit here since we don't want to make the user hunt
 * down yet another API key just for a HUD widget.
 */
object WeatherProvider {

    private fun describe(code: Int): String = when (code) {
        0 -> "Clear"
        1, 2 -> "Partly Cloudy"
        3 -> "Cloudy"
        45, 48 -> "Foggy"
        in 51..57 -> "Drizzle"
        in 61..67 -> "Rainy"
        in 71..77 -> "Snowy"
        in 80..82 -> "Rain Showers"
        in 95..99 -> "Stormy"
        else -> "Unknown"
    }

    suspend fun fetch(lat: Double, lon: Double): HudStat = withContext(Dispatchers.IO) {
        try {
            val url = "https://api.open-meteo.com/v1/forecast" +
                "?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code"
            val request = Request.Builder().url(url).get().build()
            HttpClientProvider.client.newCall(request).execute().use { response ->
                if (!response.isSuccessful) return@withContext HudStat("WEATHER", "Unavailable")
                val body = JSONObject(response.body?.string().orEmpty())
                val current = body.getJSONObject("current")
                val temp = current.getDouble("temperature_2m")
                val code = current.getInt("weather_code")
                HudStat("WEATHER", "${temp.toInt()}\u00B0C ${describe(code)}")
            }
        } catch (e: Exception) {
            HudStat("WEATHER", "Unavailable")
        }
    }
}
