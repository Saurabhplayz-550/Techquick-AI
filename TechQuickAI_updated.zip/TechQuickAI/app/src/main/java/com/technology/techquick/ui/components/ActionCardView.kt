package com.technology.techquick.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.technology.techquick.model.ActionCardData
import com.technology.techquick.model.ActionCardStatus
import com.technology.techquick.ui.theme.HudAlertRed
import com.technology.techquick.ui.theme.HudCyan
import com.technology.techquick.ui.theme.HudCyanBright
import com.technology.techquick.ui.theme.HudPanelFill
import com.technology.techquick.ui.theme.HudTextBright
import com.technology.techquick.ui.theme.HudTextMuted

/** The HUD "receipt" TechQuick shows after performing (or attempting) an action. */
@Composable
fun ActionCardView(data: ActionCardData, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier
            .fillMaxWidth()
            .shadow(
                elevation = 10.dp,
                shape = RoundedCornerShape(16.dp),
                ambientColor = HudCyan.copy(alpha = 0.35f),
                spotColor = HudCyanBright.copy(alpha = 0.45f)
            ),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = HudPanelFill.copy(alpha = 0.8f)),
        border = BorderStroke(1.dp, HudCyan.copy(alpha = 0.4f))
    ) {
        Column(Modifier.padding(14.dp)) {
            Row {
                Text(data.icon, style = MaterialTheme.typography.titleMedium)
                Spacer(Modifier.width(8.dp))
                Text(data.title, style = MaterialTheme.typography.titleMedium, color = HudTextBright)
            }
            Spacer(Modifier.height(4.dp))
            Text(data.subtitle, style = MaterialTheme.typography.bodyMedium, color = HudTextMuted)
            Spacer(Modifier.height(6.dp))
            Row {
                when (data.status) {
                    ActionCardStatus.RUNNING -> {
                        CircularProgressIndicator(Modifier.width(14.dp).height(14.dp), strokeWidth = 2.dp, color = HudCyan)
                        Spacer(Modifier.width(6.dp))
                        Text("Working...", style = MaterialTheme.typography.labelLarge, color = HudCyan)
                    }
                    ActionCardStatus.COMPLETED -> {
                        Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = HudCyanBright)
                        Spacer(Modifier.width(6.dp))
                        Text("Completed", style = MaterialTheme.typography.labelLarge, color = HudTextBright)
                    }
                    ActionCardStatus.FAILED -> {
                        Icon(Icons.Filled.Error, contentDescription = null, tint = HudAlertRed)
                        Spacer(Modifier.width(6.dp))
                        Text(data.detail ?: "Failed", style = MaterialTheme.typography.labelLarge, color = HudAlertRed)
                    }
                }
            }
        }
    }
}
