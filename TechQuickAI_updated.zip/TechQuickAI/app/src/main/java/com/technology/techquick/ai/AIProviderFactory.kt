package com.technology.techquick.ai

import com.technology.techquick.ai.providers.ClaudeProvider
import com.technology.techquick.ai.providers.GeminiProvider
import com.technology.techquick.ai.providers.OpenAICompatibleProvider
import com.technology.techquick.model.AIProviderType

object AIProviderFactory {

    private val gemini by lazy { GeminiProvider() }
    private val claude by lazy { ClaudeProvider() }
    // OpenAI, Groq, and every generic "other" free provider all share the
    // same OpenAI-compatible chat-completions implementation.
    private val openAiCompatible by lazy { OpenAICompatibleProvider() }

    fun get(type: AIProviderType): AIProvider = when (type) {
        AIProviderType.GEMINI -> gemini
        AIProviderType.CLAUDE -> claude
        AIProviderType.OPENAI, AIProviderType.GROQ, AIProviderType.OPENAI_COMPATIBLE -> openAiCompatible
    }
}
