package com.technology.techquick.actions.impl

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import com.technology.techquick.model.ActionResult
import java.net.URLEncoder

/**
 * Communication actions run immediately — no confirmation step — but are
 * careful to never claim success unless Android actually confirmed the
 * intent was handled. Calling opens the real Android dialer/call intent
 * right away; WhatsApp messaging opens the chat pre-filled and honestly
 * reports that state rather than claiming the message was sent, since
 * Android doesn't let third-party apps press "send" inside WhatsApp.
 */
class CommunicationActions(private val context: Context) {

    fun openWhatsApp(): ActionResult {
        val launch = context.packageManager.getLaunchIntentForPackage("com.whatsapp")
            ?: return ActionResult.Failure("WhatsApp doesn't seem to be installed.")
        context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        return ActionResult.Success("Opening WhatsApp.")
    }

    /** Looks up a contact's phone number by display name using the Contacts provider. */
    private fun lookupPhoneNumber(contactName: String): String? {
        val resolver = context.contentResolver
        val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
        val projection = arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
        val selection = "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} LIKE ?"
        val args = arrayOf("%$contactName%")
        resolver.query(uri, projection, selection, args, null)?.use { cursor ->
            if (cursor.moveToFirst()) {
                val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                return cursor.getString(numberIdx)
            }
        }
        return null
    }

    fun sendWhatsAppMessage(contactName: String, message: String): ActionResult {
        if (contactName.isBlank()) return ActionResult.Failure("Who should I message?")
        if (message.isBlank()) return ActionResult.Failure("What should the message say?")

        val number = lookupPhoneNumber(contactName)
            ?: return ActionResult.Failure("I couldn't find '$contactName' in your contacts.")

        val cleanNumber = number.replace(Regex("[^0-9+]"), "")
        val encodedMessage = URLEncoder.encode(message, "UTF-8")

        return try {
            // This opens WhatsApp with the message pre-filled in the chat.
            // Actually pressing send inside WhatsApp is a user action Android
            // does not let third-party apps automate — so we only ever
            // report success in getting the user to that pre-filled screen.
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/$cleanNumber?text=$encodedMessage"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ActionResult.Success(
                "Opened WhatsApp with your message to $contactName ready to send.",
                "To: $contactName"
            )
        } catch (e: Exception) {
            ActionResult.Failure("Couldn't open WhatsApp for that message.")
        }
    }

    fun openDialer(phoneNumber: String): ActionResult = try {
        val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phoneNumber")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        ActionResult.Success("Opening the dialer.", phoneNumber.ifBlank { null })
    } catch (e: Exception) {
        ActionResult.Failure("Couldn't open the dialer.")
    }

    fun callContact(contactNameOrNumber: String): ActionResult {
        val trimmed = contactNameOrNumber.trim()
        if (trimmed.isBlank()) return ActionResult.Failure("Who should I call?")

        // Treat it as a raw phone number if it has no letters and has enough
        // digits to be a real number — this tolerates spaces, dashes, dots
        // and parentheses (e.g. "(987) 654-3210", "+91 98765 43210"), which
        // the old strict digit-only check rejected and wrongly sent to
        // contact lookup instead of dialing directly.
        val digitsOnly = trimmed.filter { it.isDigit() || it == '+' }
        val looksLikeNumber = trimmed.none { it.isLetter() } && digitsOnly.count { it.isDigit() } >= 7

        val number = if (looksLikeNumber) digitsOnly else lookupPhoneNumber(trimmed)
            ?: return ActionResult.Failure("I couldn't find '$trimmed' in your contacts.")

        return try {
            val intent = Intent(Intent.ACTION_CALL, Uri.parse("tel:$number")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            ActionResult.Success("Calling $trimmed.", number)
        } catch (e: SecurityException) {
            ActionResult.Failure("I don't have permission to make calls yet. Enable the phone permission in Settings.")
        } catch (e: Exception) {
            ActionResult.Failure("Couldn't place that call.")
        }
    }
}
