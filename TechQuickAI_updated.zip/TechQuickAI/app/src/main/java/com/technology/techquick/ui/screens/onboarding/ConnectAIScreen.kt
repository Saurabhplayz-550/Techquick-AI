package com.technology.techquick.ui.screens.onboarding

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import com.technology.techquick.model.AIProviderType
import com.technology.techquick.viewmodel.ConnectionTestState
import com.technology.techquick.viewmodel.OnboardingViewModel

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun ConnectAIScreen(viewModel: OnboardingViewModel, onContinue: () -> Unit) {
    val state by viewModel.state.collectAsState()
    var providerMenuExpanded by remember { mutableStateOf(false) }
    var keyVisible by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(24.dp)
    ) {
        Text("Give TechQuick its brain \uD83E\uDDE0", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(8.dp))
        Text(
            "TechQuick uses an AI model to understand what you say. Enter your API key to connect your AI provider.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
        )
        Spacer(Modifier.height(28.dp))

        Text("AI Provider", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        ExposedDropdownMenuBox(
            expanded = providerMenuExpanded,
            onExpandedChange = { providerMenuExpanded = it }
        ) {
            OutlinedTextField(
                value = state.provider.displayName,
                onValueChange = {},
                readOnly = true,
                modifier = Modifier.fillMaxWidth().menuAnchor(),
                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = providerMenuExpanded) }
            )
            DropdownMenu(expanded = providerMenuExpanded, onDismissRequest = { providerMenuExpanded = false }) {
                AIProviderType.entries.forEach { type ->
                    DropdownMenuItem(
                        text = { Text(type.displayName) },
                        onClick = {
                            viewModel.onProviderSelected(type)
                            providerMenuExpanded = false
                        }
                    )
                }
            }
        }

        if (state.provider == AIProviderType.OPENAI_COMPATIBLE) {
            Spacer(Modifier.height(16.dp))
            Text("Base URL", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = state.baseUrl,
                onValueChange = viewModel::onBaseUrlChanged,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("e.g. https://openrouter.ai/api/v1") }
            )
            Spacer(Modifier.height(16.dp))
            Text("Model name", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = state.model,
                onValueChange = viewModel::onModelChanged,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("e.g. meta-llama/llama-3.1-8b-instruct:free") }
            )
        }

        Spacer(Modifier.height(16.dp))
        Text("API Key", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(8.dp))
        OutlinedTextField(
            value = state.apiKey,
            onValueChange = viewModel::onApiKeyChanged,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Enter your API key") },
            singleLine = true,
            visualTransformation = if (keyVisible) VisualTransformation.None else PasswordVisualTransformation(),
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
            trailingIcon = {
                IconButton(onClick = { keyVisible = !keyVisible }) {
                    Icon(if (keyVisible) Icons.Filled.VisibilityOff else Icons.Filled.Visibility, contentDescription = "Toggle visibility")
                }
            }
        )

        Spacer(Modifier.height(20.dp))
        Button(
            onClick = viewModel::testConnection,
            modifier = Modifier.fillMaxWidth().height(48.dp),
            enabled = state.testState != ConnectionTestState.TESTING
        ) {
            if (state.testState == ConnectionTestState.TESTING) {
                CircularProgressIndicator(Modifier.height(20.dp), color = MaterialTheme.colorScheme.onPrimary)
            } else {
                Text("Test Connection")
            }
        }

        Spacer(Modifier.height(12.dp))
        when (state.testState) {
            ConnectionTestState.SUCCESS -> Row {
                Icon(Icons.Filled.CheckCircle, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(Modifier.height(0.dp))
                Text("  AI connected successfully", color = MaterialTheme.colorScheme.primary)
            }
            ConnectionTestState.FAILURE -> Row {
                Icon(Icons.Filled.Error, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                Text("  ${state.testError.orEmpty()}", color = MaterialTheme.colorScheme.error)
            }
            else -> {}
        }

        Spacer(Modifier.height(28.dp))
        Button(
            onClick = {
                viewModel.saveAndContinue()
                onContinue()
            },
            modifier = Modifier.fillMaxWidth().height(52.dp),
            enabled = state.testState == ConnectionTestState.SUCCESS
        ) {
            Text("Continue to TechQuick", style = MaterialTheme.typography.titleMedium)
        }
    }
}
