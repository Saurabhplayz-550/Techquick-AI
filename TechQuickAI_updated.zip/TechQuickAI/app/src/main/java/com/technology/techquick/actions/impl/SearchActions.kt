package com.technology.techquick.actions.impl

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.technology.techquick.model.ActionResult
import java.net.URLEncoder

class SearchActions(private val context: Context) {

    private fun openUrl(url: String): Boolean = try {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }

    fun webSearch(query: String): ActionResult {
        if (query.isBlank()) return ActionResult.Failure("What should I search the web for?")
        val encoded = URLEncoder.encode(query, "UTF-8")
        return if (openUrl("https://www.google.com/search?q=$encoded"))
            ActionResult.Success("Searching the web for \"$query\".", query)
        else ActionResult.Failure("Couldn't open a browser for that search.")
    }

    fun youtubeSearch(query: String): ActionResult {
        if (query.isBlank()) return ActionResult.Failure("What should I search on YouTube for?")
        val encoded = URLEncoder.encode(query, "UTF-8")
        // Try the YouTube app first via its search intent, fall back to the web.
        val appIntent = Intent(Intent.ACTION_SEARCH).apply {
            setPackage("com.google.android.youtube")
            putExtra("query", query)
        }
        return try {
            context.startActivity(appIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            ActionResult.Success("Searching YouTube for \"$query\".", query)
        } catch (e: Exception) {
            if (openUrl("https://www.youtube.com/results?search_query=$encoded"))
                ActionResult.Success("Searching YouTube for \"$query\".", query)
            else ActionResult.Failure("Couldn't open YouTube for that search.")
        }
    }

    fun playStoreSearch(query: String): ActionResult {
        if (query.isBlank()) return ActionResult.Failure("What should I search for on the Play Store?")
        val encoded = URLEncoder.encode(query, "UTF-8")
        return if (openUrl("market://search?q=$encoded") || openUrl("https://play.google.com/store/search?q=$encoded&c=apps"))
            ActionResult.Success("Searching the Play Store for \"$query\".", query)
        else ActionResult.Failure("Couldn't open the Play Store for that search.")
    }
}
