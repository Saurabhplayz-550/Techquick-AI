package com.technology.techquick.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import com.technology.techquick.data.AppTheme

private val LightColors = lightColorScheme(
    primary = TQBlue,
    secondary = TQCyan,
    tertiary = TQPurple,
    background = TQLightBackground,
    surface = TQLightSurface,
    onBackground = TQLightOnSurface,
    onSurface = TQLightOnSurface,
    surfaceVariant = TQBluePale,
    error = TQError,
)

private val DarkColors = darkColorScheme(
    primary = TQBlue,
    secondary = TQCyan,
    tertiary = TQPurple,
    background = TQDarkBackground,
    surface = TQDarkSurface,
    onBackground = TQDarkOnSurface,
    onSurface = TQDarkOnSurface,
    surfaceVariant = TQDarkSurface,
    error = TQError,
)

@Composable
fun TechQuickTheme(appTheme: AppTheme, content: @Composable () -> Unit) {
    val useDark = when (appTheme) {
        AppTheme.LIGHT -> false
        AppTheme.DARK -> true
        AppTheme.SYSTEM -> isSystemInDarkTheme()
    }
    MaterialTheme(
        colorScheme = if (useDark) DarkColors else LightColors,
        typography = TechQuickTypography,
        content = content
    )
}
