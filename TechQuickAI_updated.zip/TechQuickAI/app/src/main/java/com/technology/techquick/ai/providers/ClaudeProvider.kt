package com.technology.techquick.ai.providers

import com.technology.techquick.ai.AIProvider
import com.technology.techquick.ai.HttpClientProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/** Anthropic Claude via the /v1/messages API. */
class ClaudeProvider : AIProvider {

    private val json = "application/json; charset=utf-8".toMediaType()

    override suspend fun sendMessage(
        systemPrompt: String,
        history: List<Pair<Boolean, String>>,
        userMessage: String,
        apiKey: String,
        baseUrl: String,
        model: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val url = "${baseUrl.trimEnd('/')}/messages"

            val messages = JSONArray()
            history.forEach { (isUser, text) ->
                messages.put(JSONObject().put("role", if (isUser) "user" else "assistant").put("content", text))
            }
            messages.put(JSONObject().put("role", "user").put("content", userMessage))

            val payload = JSONObject()
                .put("model", model)
                .put("max_tokens", 1024)
                .put("system", systemPrompt)
                .put("messages", messages)

            val request = Request.Builder()
                .url(url)
                .addHeader("x-api-key", apiKey)
                .addHeader("anthropic-version", "2023-06-01")
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(json))
                .build()

            HttpClientProvider.client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Claude error ${response.code}: ${bodyStr.take(200)}"))
                }
                val text = JSONObject(bodyStr)
                    .getJSONArray("content")
                    .getJSONObject(0)
                    .getString("text")
                Result.success(text)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun testConnection(apiKey: String, baseUrl: String, model: String): Result<Unit> =
        sendMessage(
            systemPrompt = "You are a connection test. Reply with the single word OK.",
            history = emptyList(),
            userMessage = "ping",
            apiKey = apiKey,
            baseUrl = baseUrl,
            model = model
        ).map { }
}
