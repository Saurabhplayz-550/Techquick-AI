package com.technology.techquick.ui.screens.home

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Chat
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.technology.techquick.model.ChatMessage
import com.technology.techquick.ui.components.AIOrb
import com.technology.techquick.ui.components.ActionCardView
import com.technology.techquick.ui.components.HudBackground
import com.technology.techquick.ui.components.HudWidgetCard
import com.technology.techquick.ui.components.InputBar
import com.technology.techquick.ui.components.OrbState
import com.technology.techquick.ui.components.VoiceControl
import com.technology.techquick.ui.theme.HudAlertRed
import com.technology.techquick.ui.theme.HudCyan
import com.technology.techquick.ui.theme.HudCyanBright
import com.technology.techquick.ui.theme.HudCyanDim
import com.technology.techquick.ui.theme.HudInkBottom
import com.technology.techquick.ui.theme.HudInkTop
import com.technology.techquick.ui.theme.HudPanelFill
import com.technology.techquick.ui.theme.HudTextBright
import com.technology.techquick.ui.theme.HudTextMuted
import com.technology.techquick.viewmodel.HomeViewModel
import java.util.Calendar
import java.text.SimpleDateFormat
import java.util.Locale

private fun timeGreeting(): Pair<String, Boolean> {
    val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
    return when {
        hour < 12 -> "GOOD MORNING, SIR" to true
        hour < 17 -> "GOOD AFTERNOON, SIR" to true
        else -> "GOOD EVENING, SIR" to false
    }
}

private fun orbLabel(state: OrbState): String = when (state) {
    OrbState.IDLE -> "ACTIVE"
    OrbState.LISTENING -> "LISTENING"
    OrbState.THINKING -> "THINKING"
    OrbState.EXECUTING -> "WORKING"
    OrbState.FINISHED -> "ACTIVE"
}

/**
 * The TechQuick HUD home screen. This is deliberately NOT a chat transcript:
 * only the single latest turn (the user's query, then TechQuick's reply) is
 * ever on screen at once, each replacing the last with a quick cross-fade —
 * exactly one thing being said at a time, like a HUD readout rather than a
 * scrollback log. Full history still flows to the AI for context; it's just
 * never rendered as a list.
 */
@Composable
fun HomeScreen(
    viewModel: HomeViewModel,
    onOpenSettings: () -> Unit,
    onNeedsApiKey: () -> Unit
) {
    val state by viewModel.state.collectAsState()

    LaunchedEffect(state.hasApiKey) {
        if (!state.hasApiKey) onNeedsApiKey()
    }

    val (greeting, isDay) = timeGreeting()
    val timeLabel = rememberNowLabel()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Brush.verticalGradient(listOf(HudInkTop, HudInkBottom)))
    ) {
        HudBackground(modifier = Modifier.fillMaxSize())

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 18.dp, vertical = 14.dp)
        ) {
            // Top bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onOpenSettings) {
                    Icon(Icons.Filled.Menu, contentDescription = "Menu", tint = HudCyan)
                }
                Text(
                    "TECHQUICK",
                    style = MaterialTheme.typography.titleLarge.copy(
                        shadow = Shadow(color = HudCyan.copy(alpha = 0.85f), blurRadius = 22f)
                    ),
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Black,
                    letterSpacing = 4.sp,
                    color = HudCyanBright
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.AutoMirrored.Filled.Chat,
                        contentDescription = "Messages",
                        tint = HudTextBright,
                        modifier = Modifier.size(20.dp)
                    )
                    Box {
                        Icon(
                            Icons.Filled.Notifications,
                            contentDescription = "Alerts",
                            tint = HudTextBright,
                            modifier = Modifier.size(20.dp)
                        )
                        // Only shown when there's a real unread count — no fake badge.
                        if (state.unreadNotificationCount > 0) {
                            Box(
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .offset(x = 6.dp, y = (-4).dp)
                                    .size(15.dp)
                                    .background(HudAlertRed, CircleShape),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    state.unreadNotificationCount.coerceAtMost(9).toString(),
                                    style = MaterialTheme.typography.labelSmall,
                                    color = HudTextBright,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            Spacer(Modifier.height(10.dp))
            // Thin glowing HUD divider under the header, like the reference
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(1.4.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, HudCyan.copy(alpha = 0.75f), Color.Transparent)
                        )
                    )
            )
            Spacer(Modifier.height(6.dp))

            // Greeting row
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    if (isDay) Icons.Filled.WbSunny else Icons.Filled.NightsStay,
                    contentDescription = null,
                    tint = HudCyan,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(Modifier.width(6.dp))
                Column {
                    Text(
                        greeting,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = HudTextBright
                    )
                    Text(
                        "Time: $timeLabel",
                        style = MaterialTheme.typography.labelSmall,
                        color = HudCyanDim
                    )
                }
            }

            state.errorBanner?.let { error ->
                Spacer(Modifier.height(8.dp))
                Surface(
                    color = HudPanelFill.copy(alpha = 0.85f),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, HudAlertRed.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("⚠ $error", modifier = Modifier.padding(10.dp), color = HudAlertRed)
                }
            }

            Spacer(Modifier.height(10.dp))

            // Widget flanks + central orb
            Row(
                modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HudWidgetCard(state.hud.weather)
                    HudWidgetCard(state.hud.location)
                    HudWidgetCard(state.hud.calendar)
                }

                Box(
                    modifier = Modifier
                        .width(168.dp)
                        .shadow(
                            elevation = 28.dp,
                            shape = CircleShape,
                            ambientColor = HudCyan.copy(alpha = 0.5f),
                            spotColor = HudCyanBright.copy(alpha = 0.6f)
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    AIOrb(state = state.orbState, size = 158.dp)
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            "TECHQUICK",
                            style = MaterialTheme.typography.labelMedium,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            letterSpacing = 1.sp,
                            color = HudTextBright
                        )
                        Text(
                            orbLabel(state.orbState),
                            style = MaterialTheme.typography.labelSmall,
                            fontFamily = FontFamily.Monospace,
                            letterSpacing = 1.sp,
                            color = HudCyanBright
                        )
                    }
                }

                Column(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    HudWidgetCard(state.hud.battery)
                    HudWidgetCard(state.hud.systemHealth)
                    HudWidgetCard(state.hud.connectivity)
                }
            }

            Spacer(Modifier.height(14.dp))

            // Transient response area — one turn at a time, never a scrollback list.
            val latest = state.messages.lastOrNull()
            AnimatedContent(
                targetState = latest,
                transitionSpec = { fadeIn(tween(280)) togetherWith fadeOut(tween(200)) },
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 10.dp,
                        shape = RoundedCornerShape(16.dp),
                        ambientColor = HudCyan.copy(alpha = 0.3f),
                        spotColor = HudCyanBright.copy(alpha = 0.4f)
                    ),
                label = "response"
            ) { message ->
                ResponseArea(
                    message = message,
                    onConfirm = { msg ->
                        msg.pendingConfirmation?.let {
                            viewModel.confirmAction(msg.id, it.actionType, it.parameters)
                        }
                    },
                    onCancel = { msg -> viewModel.cancelAction(msg.id) }
                )
            }

            // Flexible gap: absorbs whatever height is left on the device,
            // so the mic and the input bar are anchored to the bottom of
            // the screen instead of floating mid-screen with dead space
            // below them on taller phones.
            Spacer(Modifier.weight(1f))

            // Voice deck: waveform clusters flanking the mic, curved ring text
            VoiceControl(
                isListening = state.isListening,
                onTap = { if (!state.isListening) viewModel.startListening() },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(Modifier.height(14.dp))

            InputBar(
                text = state.inputText,
                onTextChange = viewModel::onInputChange,
                onSend = { viewModel.sendMessage() },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
private fun ResponseArea(
    message: ChatMessage?,
    onConfirm: (ChatMessage) -> Unit,
    onCancel: (ChatMessage) -> Unit
) {
    if (message == null) {
        Text(
            "Welcome back!\nHow can I assist you today?",
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            color = HudTextBright,
            modifier = Modifier.fillMaxWidth()
        )
        return
    }

    val confirmation = message.pendingConfirmation
    val actionCard = message.actionCard
    when {
        confirmation != null -> {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .shadow(
                        elevation = 10.dp,
                        shape = RoundedCornerShape(16.dp),
                        ambientColor = HudCyan.copy(alpha = 0.35f),
                        spotColor = HudCyanBright.copy(alpha = 0.45f)
                    )
                    .clip(RoundedCornerShape(16.dp))
                    .background(HudPanelFill.copy(alpha = 0.85f))
                    .border(1.dp, HudCyanDim.copy(alpha = 0.6f), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Text(confirmation.title, style = MaterialTheme.typography.titleMedium, color = HudTextBright)
                Spacer(Modifier.height(4.dp))
                Text(confirmation.description, style = MaterialTheme.typography.bodyMedium, color = HudTextMuted)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(
                        onClick = { onCancel(message) },
                        border = BorderStroke(1.dp, HudCyanDim),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = HudTextBright)
                    ) { Text("Cancel") }
                    Button(
                        onClick = { onConfirm(message) },
                        colors = ButtonDefaults.buttonColors(containerColor = HudCyan, contentColor = HudInkTop)
                    ) { Text("Confirm") }
                }
            }
        }
        actionCard != null -> ActionCardView(actionCard, modifier = Modifier.fillMaxWidth())
        else -> Text(
            message.text,
            style = MaterialTheme.typography.titleMedium,
            textAlign = TextAlign.Center,
            color = HudTextBright,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

@Composable
private fun rememberNowLabel(): String {
    var label by remember {
        mutableStateOf(SimpleDateFormat("h:mm a", Locale.getDefault()).format(Calendar.getInstance().time))
    }
    LaunchedEffect(Unit) {
        while (true) {
            label = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Calendar.getInstance().time)
            kotlinx.coroutines.delay(30_000)
        }
    }
    return label
}
