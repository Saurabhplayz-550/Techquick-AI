package com.technology.techquick.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.technology.techquick.ui.theme.HudBlue
import com.technology.techquick.ui.theme.HudCyan
import com.technology.techquick.ui.theme.HudCyanBright
import com.technology.techquick.ui.theme.HudInkTop
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

enum class OrbState { IDLE, LISTENING, THINKING, EXECUTING, FINISHED }

/**
 * TechQuick's signature reactor: a tick-marked dial ring, two independently
 * rotating energy rings, and a glowing plasma core, all drawn with Canvas —
 * no image assets, so it scales crisply and reacts instantly to state.
 * Colors are fixed to the HUD palette (not MaterialTheme) so the reactor
 * always reads as the same cinematic cyan console, in light or dark mode.
 */
@Composable
fun AIOrb(state: OrbState, modifier: Modifier = Modifier, size: Dp = 220.dp) {
    val infinite = rememberInfiniteTransition(label = "orb")

    // Main energy ring: clockwise, speed reacts to state
    val cwSpeedMs = when (state) {
        OrbState.LISTENING -> 2600
        OrbState.THINKING -> 1400
        OrbState.EXECUTING -> 1000
        else -> 6000
    }
    val clockwiseRotation by infinite.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(cwSpeedMs, easing = LinearEasing)), label = "cw"
    )

    // Inner ring: anti-clockwise, always a bit faster for a "gyroscope" feel
    val ccwSpeedMs = when (state) {
        OrbState.LISTENING -> 1800
        OrbState.THINKING -> 950
        OrbState.EXECUTING -> 700
        else -> 4200
    }
    val counterRotation by infinite.animateFloat(
        initialValue = 360f, targetValue = 0f,
        animationSpec = infiniteRepeatable(tween(ccwSpeedMs, easing = LinearEasing)), label = "ccw"
    )

    // Outer tick-mark dial: very slow constant drift, doubles as the outer
    // dashed boundary ring's rotation so we don't add a third animation.
    val driftRotation by infinite.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(if (state == OrbState.EXECUTING) 4000 else 9000, easing = LinearEasing)), label = "drift"
    )

    val corePulse by infinite.animateFloat(
        initialValue = if (state == OrbState.LISTENING) 0.9f else 0.97f,
        targetValue = if (state == OrbState.LISTENING) 1.14f else 1.03f,
        animationSpec = infiniteRepeatable(
            tween(if (state == OrbState.LISTENING) 550 else 2000, easing = LinearEasing),
            RepeatMode.Reverse
        ), label = "corePulse"
    )

    // 3D tilt clock — one shared 0..360 phase, but each state turns it into
    // a different *shape* of motion (not just a different speed), like a
    // hologram that genuinely behaves differently depending on what it's
    // doing: idle sways gently, listening tracks side to side more alertly,
    // thinking turns like a globe, executing spins fast with a busy jitter.
    val tiltPeriodMs = when (state) {
        OrbState.LISTENING -> 3200
        OrbState.THINKING -> 2600
        OrbState.EXECUTING -> 1500
        else -> 7000
    }
    val tiltPhase by infinite.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(tiltPeriodMs, easing = LinearEasing)), label = "tilt"
    )
    val tiltRad = tiltPhase * (PI.toFloat() / 180f)
    val rotY: Float
    val rotX: Float
    when (state) {
        OrbState.THINKING -> {
            // Full turntable spin around the vertical axis, like a globe
            // turning over while it works something out.
            rotY = tiltPhase
            rotX = 8f + sin(tiltRad * 2f) * 4f
        }
        OrbState.EXECUTING -> {
            // Faster spin plus a busier nod — reads as "working hard". Uses
            // a whole number of spins per cycle (2x) so the loop point is
            // seamless — a fractional multiplier would visibly jump each
            // time the shared phase resets.
            rotY = (tiltPhase * 2f) % 360f
            rotX = 10f + sin(tiltRad * 4f) * 7f
        }
        OrbState.LISTENING -> {
            // Not a spin — a wide, alert side-to-side turn, leaned in as if
            // tracking a voice, rather than a lazy idle sway.
            rotY = sin(tiltRad) * 24f
            rotX = 15f + sin(tiltRad * 2f) * 3f
        }
        else -> {
            // IDLE / FINISHED: a small, slow, lazy sway.
            rotY = sin(tiltRad) * 12f
            rotX = 9f + sin(tiltRad * 0.5f) * 2f
        }
    }

    val accent = when (state) {
        OrbState.LISTENING -> HudCyanBright
        OrbState.THINKING -> HudBlue
        OrbState.EXECUTING -> HudCyanBright
        else -> HudCyan
    }

    Box(
        modifier = modifier
            .size(size)
            .graphicsLayer {
                rotationX = rotX
                rotationY = rotY
                cameraDistance = 10f * density
                alpha = 0.86f
            },
        contentAlignment = Alignment.Center
    ) {
        // Layered ambient glow — a wide soft haze plus a tighter hot core,
        // so the bloom reads as physically luminous rather than a flat blur.
        Box(
            Modifier
                .size(size * 1.05f)
                .blur(46.dp)
                .background(Brush.radialGradient(listOf(accent.copy(alpha = 0.30f), Color.Transparent)), CircleShape)
        )
        Box(
            Modifier
                .size(size * 0.75f)
                .blur(28.dp)
                .background(Brush.radialGradient(listOf(accent.copy(alpha = 0.45f), Color.Transparent)), CircleShape)
        )

        Canvas(modifier = Modifier.size(size)) {
            val d = min(this.size.width, this.size.height)
            val cx = this.size.width / 2f
            val cy = this.size.height / 2f
            val thinStroke = d * 0.010f

            // --- Tick-mark dial: evenly spaced ticks around the outer edge,
            // every 5th one longer + brighter, like a radar/reactor gauge.
            rotate(driftRotation) {
                val tickCount = 48
                val outerR = d * 0.485f
                repeat(tickCount) { i ->
                    val angle = (2 * Math.PI * i / tickCount).toFloat()
                    val major = i % 5 == 0
                    val innerR = outerR - (if (major) d * 0.035f else d * 0.018f)
                    val ux = cos(angle); val uy = sin(angle)
                    drawLine(
                        color = accent.copy(alpha = if (major) 0.85f else 0.4f),
                        start = Offset(cx + ux * innerR, cy + uy * innerR),
                        end = Offset(cx + ux * outerR, cy + uy * outerR),
                        strokeWidth = if (major) thinStroke * 1.8f else thinStroke,
                        cap = StrokeCap.Round
                    )
                }
            }

            // --- Outer boundary ring: thin, mostly-full circle, static
            drawArc(
                color = accent.copy(alpha = 0.22f),
                startAngle = 0f, sweepAngle = 360f, useCenter = false,
                style = Stroke(width = thinStroke, cap = StrokeCap.Round),
                topLeft = Offset((this.size.width - d * 0.86f) / 2f, (this.size.height - d * 0.86f) / 2f),
                size = Size(d * 0.86f, d * 0.86f)
            )

            // --- Main energized ring: thick sweep gradient, clockwise
            rotate(clockwiseRotation) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(Color.Transparent, accent, accent, Color.Transparent)),
                    startAngle = 0f, sweepAngle = 300f, useCenter = false,
                    style = Stroke(width = d * 0.028f, cap = StrokeCap.Round),
                    topLeft = Offset((this.size.width - d * 0.80f) / 2f, (this.size.height - d * 0.80f) / 2f),
                    size = Size(d * 0.80f, d * 0.80f)
                )
            }

            // --- Inner gyroscope ring: thinner, counter-clockwise
            rotate(counterRotation) {
                drawArc(
                    brush = Brush.sweepGradient(listOf(Color.Transparent, HudCyanBright, Color.Transparent)),
                    startAngle = 0f, sweepAngle = 210f, useCenter = false,
                    style = Stroke(width = d * 0.018f, cap = StrokeCap.Round),
                    topLeft = Offset((this.size.width - d * 0.60f) / 2f, (this.size.height - d * 0.60f) / 2f),
                    size = Size(d * 0.60f, d * 0.60f)
                )
            }
        }

        // Glowing plasma core — glass-like: translucent dark base fading to
        // a bright cyan bloom at the rim, so it reads as lit glass with the
        // background haze showing through, rather than a solid disc.
        Box(
            Modifier
                .size(size * 0.42f * corePulse)
                .background(
                    Brush.radialGradient(listOf(HudInkTop.copy(alpha = 0.55f), accent.copy(alpha = 0.85f), HudCyanBright)),
                    CircleShape
                )
        )
        Box(
            Modifier
                .size(size * 0.13f)
                .background(HudInkTop.copy(alpha = 0.25f), CircleShape)
        )
    }
}
