package com.technology.techquick.ai

import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

/** Shared OkHttp client, reused across all AI providers. */
object HttpClientProvider {
    val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(45, TimeUnit.SECONDS)
        .writeTimeout(20, TimeUnit.SECONDS)
        .build()
}
