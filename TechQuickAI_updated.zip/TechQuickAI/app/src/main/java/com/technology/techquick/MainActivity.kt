package com.technology.techquick

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.technology.techquick.navigation.Routes
import com.technology.techquick.ui.screens.home.HomeScreen
import com.technology.techquick.ui.screens.onboarding.ConnectAIScreen
import com.technology.techquick.ui.screens.onboarding.WelcomeScreen
import com.technology.techquick.ui.screens.settings.SettingsScreen
import com.technology.techquick.ui.screens.personality.PersonalityScreen
import com.technology.techquick.ui.screens.memory.MemoryScreen
import com.technology.techquick.ui.theme.TechQuickTheme
import com.technology.techquick.util.PermissionUtils
import com.technology.techquick.viewmodel.HomeViewModel
import com.technology.techquick.viewmodel.MemoryViewModel
import com.technology.techquick.viewmodel.OnboardingViewModel
import com.technology.techquick.viewmodel.PersonalityViewModel
import com.technology.techquick.viewmodel.SettingsViewModel

class MainActivity : ComponentActivity() {

    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { /* results handled by system dialogs as needed */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ask for the assistant's runtime permissions up front so voice
        // input and contact/call actions work the first time they're used,
        // without blocking any part of the UI that doesn't need them.
        permissionLauncher.launch(PermissionUtils.REQUIRED_PERMISSIONS)

        val app = application as TechQuickApplication

        setContent {
            val theme by app.settingsRepository.theme.collectAsState()
            TechQuickTheme(appTheme = theme) {
                val navController = rememberNavController()
                val startDestination = if (app.settingsRepository.hasApiKey()) Routes.HOME else Routes.WELCOME

                val homeViewModel: HomeViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = HomeViewModel.factory(app))
                val onboardingViewModel: OnboardingViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = OnboardingViewModel.factory(app))
                val settingsViewModel: SettingsViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = SettingsViewModel.factory(app))
                val personalityViewModel: PersonalityViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = PersonalityViewModel.factory(app))
                val memoryViewModel: MemoryViewModel = androidx.lifecycle.viewmodel.compose.viewModel(factory = MemoryViewModel.factory(app))

                NavHost(navController = navController, startDestination = startDestination) {
                    composable(Routes.WELCOME) {
                        WelcomeScreen(onGetStarted = { navController.navigate(Routes.CONNECT_AI) })
                    }
                    composable(Routes.CONNECT_AI) {
                        ConnectAIScreen(
                            viewModel = onboardingViewModel,
                            onContinue = {
                                navController.navigate(Routes.HOME) {
                                    popUpTo(Routes.WELCOME) { inclusive = true }
                                }
                            }
                        )
                    }
                    composable(Routes.HOME) {
                        HomeScreen(
                            viewModel = homeViewModel,
                            onOpenSettings = { navController.navigate(Routes.SETTINGS) },
                            onNeedsApiKey = {
                                navController.navigate(Routes.CONNECT_AI) {
                                    popUpTo(Routes.HOME) { inclusive = true }
                                }
                            }
                        )
                    }
                    composable(Routes.SETTINGS) {
                        settingsViewModel.refresh()
                        SettingsScreen(
                            viewModel = settingsViewModel,
                            onBack = { navController.popBackStack() },
                            onChangeApiKey = { navController.navigate(Routes.CONNECT_AI) },
                            onOpenPersonality = { navController.navigate(Routes.PERSONALITY) },
                            onOpenMemory = { navController.navigate(Routes.MEMORY) }
                        )
                    }
                    composable(Routes.PERSONALITY) {
                        PersonalityScreen(viewModel = personalityViewModel, onBack = { navController.popBackStack() })
                    }
                    composable(Routes.MEMORY) {
                        MemoryScreen(viewModel = memoryViewModel, onBack = { navController.popBackStack() })
                    }
                }
            }
        }
    }
}
