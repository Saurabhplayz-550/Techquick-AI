package com.technology.techquick.assistant

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.technology.techquick.TechQuickApplication

/** If the user had "Hey TechQuick" always-listening turned on, resume it after the phone reboots. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val app = context.applicationContext as? TechQuickApplication ?: return
        if (app.settingsRepository.alwaysListeningEnabled) {
            WakeWordService.start(context)
        }
    }
}
