package com.technology.techquick.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

/**
 * Lets TechQuick "see" the screen and "touch" it on the user's behalf, the
 * same way TalkBack / Voice Access do. Two capabilities only:
 *
 *  - [readScreen]: walks every visible window's accessibility tree (this
 *    includes the on-screen keyboard, notification shade, etc. — not just
 *    the foreground app) and returns the text on screen, for
 *    "screen par kya likha hai".
 *  - [clickByLabel]: finds the on-screen element whose text / content
 *    description / resource-id best matches a spoken label ("clock icon",
 *    "send button", keyboard key "S") and either performs a real
 *    ACTION_CLICK on it, or — if it isn't itself a distinct clickable node
 *    — taps its on-screen center with a synthetic gesture.
 *
 * Both only work once the user has turned this service on from Android
 * Settings > Accessibility. TechQuick can deep-link there but can never
 * enable it silently — that's an OS restriction on every Android version,
 * not something this app can bypass.
 */
class TechQuickAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // No live tracking needed — readScreen()/clickByLabel() pull the
        // current tree on demand instead of reacting to every event.
    }

    override fun onInterrupt() {}

    override fun onUnbind(intent: Intent?): Boolean {
        if (instance === this) instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    /** Concatenates every piece of visible text/label across all windows. */
    fun readScreen(): String {
        val pieces = LinkedHashSet<String>()
        for (window in safeWindows()) {
            val root = window.root ?: continue
            collectText(root, pieces)
        }
        if (pieces.isEmpty()) {
            rootInActiveWindow?.let { collectText(it, pieces) }
        }
        return pieces.joinToString(". ")
    }

    /** Finds the best-matching element for [label] anywhere on screen and taps it. */
    fun clickByLabel(label: String): Boolean {
        val target = normalize(label)
        if (target.isBlank()) return false

        var best: AccessibilityNodeInfo? = null
        var bestScore = 0

        for (window in safeWindows()) {
            val root = window.root ?: continue
            findBestMatch(root, target)?.let { (node, score) ->
                if (score > bestScore) {
                    bestScore = score
                    best = node
                }
            }
        }
        if (best == null) {
            rootInActiveWindow?.let { root ->
                findBestMatch(root, target)?.let { (node, score) ->
                    if (score > bestScore) {
                        bestScore = score
                        best = node
                    }
                }
            }
        }

        val node = best ?: return false
        return performClick(node)
    }

    private fun collectText(node: AccessibilityNodeInfo, out: MutableSet<String>) {
        val text = node.text?.toString()?.trim()
        val desc = node.contentDescription?.toString()?.trim()
        if (!text.isNullOrBlank()) out.add(text)
        if (!desc.isNullOrBlank() && desc != text) out.add(desc)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collectText(child, out)
        }
    }

    /** Walks the tree scoring every node against [target]; returns the single best match. */
    private fun findBestMatch(node: AccessibilityNodeInfo, target: String): Pair<AccessibilityNodeInfo, Int>? {
        var bestNode: AccessibilityNodeInfo? = null
        var bestScore = 0

        val score = scoreNode(node, target)
        if (score > bestScore) {
            bestScore = score
            bestNode = node
        }

        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val childBest = findBestMatch(child, target)
            if (childBest != null && childBest.second > bestScore) {
                bestScore = childBest.second
                bestNode = childBest.first
            }
        }

        return bestNode?.let { it to bestScore }
    }

    private fun scoreNode(node: AccessibilityNodeInfo, target: String): Int {
        val text = normalize(node.text?.toString())
        val desc = normalize(node.contentDescription?.toString())
        val viewId = normalize(node.viewIdResourceName?.substringAfterLast('/'))

        return when {
            text == target || desc == target || viewId == target -> 100
            text.isNotBlank() && (text.startsWith(target) || target.startsWith(text)) -> 80
            desc.isNotBlank() && (desc.startsWith(target) || target.startsWith(desc)) -> 75
            viewId.isNotBlank() && viewId.contains(target) -> 60
            text.isNotBlank() && text.contains(target) -> 55
            desc.isNotBlank() && desc.contains(target) -> 50
            else -> 0
        }
    }

    private fun performClick(rawNode: AccessibilityNodeInfo): Boolean {
        // Climb to the nearest clickable ancestor — icons/keys are often a
        // plain TextView/ImageView sitting inside the real clickable container.
        var node: AccessibilityNodeInfo? = rawNode
        var hops = 0
        while (node != null && !node.isClickable && hops < 6) {
            node = node.parent
            hops++
        }
        if (node != null && node.isClickable) {
            return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
        }
        // Nothing clickable in the ancestry — tap the original node's
        // on-screen center directly instead.
        val bounds = Rect()
        rawNode.getBoundsInScreen(bounds)
        if (bounds.width() <= 0 || bounds.height() <= 0) return false
        return tap(bounds.exactCenterX(), bounds.exactCenterY())
    }

    private fun tap(x: Float, y: Float): Boolean {
        val path = Path().apply { moveTo(x, y) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    private fun safeWindows(): List<AccessibilityWindowInfo> =
        try { windows ?: emptyList() } catch (e: Exception) { emptyList() }

    private fun normalize(s: String?): String = s?.trim()?.lowercase().orEmpty()

    companion object {
        @Volatile private var instance: TechQuickAccessibilityService? = null

        fun isEnabled(): Boolean = instance != null

        fun readScreen(): String? = instance?.readScreen()

        fun clickByLabel(label: String): Boolean = instance?.clickByLabel(label) ?: false
    }
}
