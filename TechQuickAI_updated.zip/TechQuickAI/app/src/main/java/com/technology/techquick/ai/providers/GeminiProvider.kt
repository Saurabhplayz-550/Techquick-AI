package com.technology.techquick.ai.providers

import com.technology.techquick.ai.AIProvider
import com.technology.techquick.ai.HttpClientProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject

/** Google Gemini via the generativelanguage REST API. */
class GeminiProvider : AIProvider {

    private val json = "application/json; charset=utf-8".toMediaType()

    override suspend fun sendMessage(
        systemPrompt: String,
        history: List<Pair<Boolean, String>>,
        userMessage: String,
        apiKey: String,
        baseUrl: String,
        model: String
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val url = "${baseUrl.trimEnd('/')}/models/$model:generateContent?key=$apiKey"

            val contents = JSONArray()
            history.forEach { (isUser, text) ->
                contents.put(
                    JSONObject()
                        .put("role", if (isUser) "user" else "model")
                        .put("parts", JSONArray().put(JSONObject().put("text", text)))
                )
            }
            contents.put(
                JSONObject()
                    .put("role", "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", userMessage)))
            )

            val payload = JSONObject()
                .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", systemPrompt))))
                .put("contents", contents)
                .put("generationConfig", JSONObject().put("temperature", 0.4))

            val request = Request.Builder()
                .url(url)
                .addHeader("Content-Type", "application/json")
                .post(payload.toString().toRequestBody(json))
                .build()

            HttpClientProvider.client.newCall(request).execute().use { response ->
                val bodyStr = response.body?.string().orEmpty()
                if (!response.isSuccessful) {
                    return@withContext Result.failure(Exception("Gemini error ${response.code}: ${bodyStr.take(200)}"))
                }
                val text = JSONObject(bodyStr)
                    .getJSONArray("candidates")
                    .getJSONObject(0)
                    .getJSONObject("content")
                    .getJSONArray("parts")
                    .getJSONObject(0)
                    .getString("text")
                Result.success(text)
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    override suspend fun testConnection(apiKey: String, baseUrl: String, model: String): Result<Unit> =
        sendMessage(
            systemPrompt = "You are a connection test. Reply with the single word OK.",
            history = emptyList(),
            userMessage = "ping",
            apiKey = apiKey,
            baseUrl = baseUrl,
            model = model
        ).map { }
}
