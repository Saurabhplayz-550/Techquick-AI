package com.technology.techquick.data

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import java.security.KeyStore

/**
 * Wraps Android's EncryptedSharedPreferences (backed by the Android
 * Keystore) so API keys are never stored, logged, or hard-coded in plain
 * text anywhere in the app.
 *
 * IMPORTANT: On some OEM ROMs (Xiaomi/MIUI in particular, but also some
 * Oppo/Vivo/Realme builds) the Android Keystore provider is flaky enough
 * that creating/opening the master key can throw instead of just working —
 * a corrupted keystore entry from a previous install is the most common
 * cause. Because this class is built inside Application.onCreate(), any
 * uncaught exception here used to crash the app before a single frame of
 * UI was ever drawn (the "opens to a white screen and closes itself"
 * report). We now: (1) try the normal encrypted path, (2) if that fails,
 * wipe just our own keystore entry and retry once (fixes the common
 * "corrupted from a previous install" case), and (3) if it still fails,
 * fall back to a plain, app-private SharedPreferences file instead of
 * crashing. Falling back is strictly better than a crash loop that leaves
 * the user unable to open the app at all; app-private prefs are still not
 * readable by other apps on a non-rooted device.
 */
class SecureStorage(context: Context) {

    private val prefs: SharedPreferences = createEncryptedPrefsSafely(context)

    private fun createEncryptedPrefsSafely(context: Context): SharedPreferences {
        return try {
            buildEncryptedPrefs(context)
        } catch (e: Exception) {
            Log.w(TAG, "Encrypted prefs failed, clearing stale keystore entry and retrying once", e)
            try {
                clearKeystoreEntry()
                buildEncryptedPrefs(context)
            } catch (e2: Exception) {
                Log.e(TAG, "Encrypted prefs unavailable on this device, falling back to plain storage", e2)
                context.getSharedPreferences(FALLBACK_PREFS_NAME, Context.MODE_PRIVATE)
            }
        }
    }

    private fun buildEncryptedPrefs(context: Context): SharedPreferences {
        val masterKey = MasterKey.Builder(context)
            .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
            .build()

        return EncryptedSharedPreferences.create(
            context,
            SECURE_PREFS_NAME,
            masterKey,
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
    }

    /** Removes just TechQuick's own master key alias so a corrupted entry can't keep crashing every launch. */
    private fun clearKeystoreEntry() {
        try {
            val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE_PROVIDER)
            keyStore.load(null)
            if (keyStore.containsAlias(MASTER_KEY_ALIAS)) {
                keyStore.deleteEntry(MASTER_KEY_ALIAS)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Couldn't clear keystore entry (non-fatal, will fall back if needed)", e)
        }
    }

    fun saveApiKey(key: String) = prefs.edit().putString(KEY_API_KEY, key).apply()
    fun getApiKey(): String? = prefs.getString(KEY_API_KEY, null)
    fun clearApiKey() = prefs.edit().remove(KEY_API_KEY).apply()

    fun saveProvider(providerName: String) = prefs.edit().putString(KEY_PROVIDER, providerName).apply()
    fun getProvider(): String? = prefs.getString(KEY_PROVIDER, null)

    fun saveBaseUrl(url: String) = prefs.edit().putString(KEY_BASE_URL, url).apply()
    fun getBaseUrl(): String? = prefs.getString(KEY_BASE_URL, null)

    fun saveModel(model: String) = prefs.edit().putString(KEY_MODEL, model).apply()
    fun getModel(): String? = prefs.getString(KEY_MODEL, null)

    fun clearAll() = prefs.edit().clear().apply()

    fun hasValidConfig(): Boolean = !getApiKey().isNullOrBlank() && !getProvider().isNullOrBlank()

    private companion object {
        const val TAG = "SecureStorage"
        const val SECURE_PREFS_NAME = "techquick_secure_prefs"
        const val FALLBACK_PREFS_NAME = "techquick_secure_prefs_fallback"
        const val MASTER_KEY_ALIAS = "_androidx_security_master_key_"
        const val ANDROID_KEYSTORE_PROVIDER = "AndroidKeyStore"
        const val KEY_API_KEY = "api_key"
        const val KEY_PROVIDER = "provider"
        const val KEY_BASE_URL = "base_url"
        const val KEY_MODEL = "model"
    }
}
