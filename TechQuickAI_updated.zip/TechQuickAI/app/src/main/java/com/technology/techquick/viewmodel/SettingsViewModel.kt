package com.technology.techquick.viewmodel

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.technology.techquick.TechQuickApplication
import com.technology.techquick.accessibility.TechQuickAccessibilityService
import com.technology.techquick.actions.impl.DeviceActions
import com.technology.techquick.assistant.WakeWordService
import com.technology.techquick.data.AppTheme
import com.technology.techquick.data.ResponseStyle
import com.technology.techquick.model.AIProviderType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class SettingsUiState(
    val theme: AppTheme = AppTheme.SYSTEM,
    val voiceResponsesEnabled: Boolean = true,
    val responseStyle: ResponseStyle = ResponseStyle.CONCISE,
    val providerName: String = "",
    val hasApiKey: Boolean = false,
    val deviceAdminActive: Boolean = false,
    val alwaysListeningEnabled: Boolean = false,
    val accessibilityServiceEnabled: Boolean = false,
    val ignoringBatteryOptimizations: Boolean = false
)

class SettingsViewModel(private val app: TechQuickApplication) : ViewModel() {

    private val deviceActions = DeviceActions(app)

    private val _state = MutableStateFlow(loadState())
    val state: StateFlow<SettingsUiState> = _state

    private fun loadState(): SettingsUiState {
        val config = app.settingsRepository.getAIConfig()
        return SettingsUiState(
            theme = app.settingsRepository.theme.value,
            voiceResponsesEnabled = app.settingsRepository.voiceResponsesEnabled,
            responseStyle = app.settingsRepository.responseStyle,
            providerName = config?.providerType?.displayName ?: "Not connected",
            hasApiKey = app.settingsRepository.hasApiKey(),
            deviceAdminActive = deviceActions.isDeviceAdminActive(),
            alwaysListeningEnabled = app.settingsRepository.alwaysListeningEnabled,
            accessibilityServiceEnabled = TechQuickAccessibilityService.isEnabled(),
            ignoringBatteryOptimizations = isIgnoringBatteryOptimizations()
        )
    }

    private fun isIgnoringBatteryOptimizations(): Boolean {
        val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
        return pm.isIgnoringBatteryOptimizations(app.packageName)
    }

    fun deviceAdminIntent() = deviceActions.requestDeviceAdminIntent()

    /** Turns "Hey TechQuick" background listening on/off. Persists the choice so BootReceiver can resume it. */
    fun setAlwaysListening(enabled: Boolean) {
        app.settingsRepository.alwaysListeningEnabled = enabled
        if (enabled) WakeWordService.start(app) else WakeWordService.stop(app)
        refresh()
    }

    /** Android requires the user to grant Accessibility permission manually — no app can do this silently. */
    fun accessibilitySettingsIntent(): Intent =
        Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)

    /** Android requires an explicit user tap on its own system dialog to exempt an app from battery optimization. */
    fun batteryOptimizationIntent(): Intent =
        if (isIgnoringBatteryOptimizations())
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${app.packageName}"))
        else
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${app.packageName}"))

    fun refresh() { _state.value = loadState() }

    fun setTheme(theme: AppTheme) {
        app.settingsRepository.setTheme(theme)
        refresh()
    }

    fun setVoiceResponses(enabled: Boolean) {
        app.settingsRepository.voiceResponsesEnabled = enabled
        refresh()
    }

    fun setResponseStyle(style: ResponseStyle) {
        app.settingsRepository.responseStyle = style
        refresh()
    }

    fun removeApiKey() {
        app.settingsRepository.removeApiKey()
        app.conversationRepository.clear()
        refresh()
    }

    fun clearConversationHistory() {
        app.conversationRepository.clear()
    }

    fun testCurrentConnection(onResult: (Boolean) -> Unit) {
        val config = app.settingsRepository.getAIConfig() ?: run { onResult(false); return }
        viewModelScope.launch {
            val result = app.aiBrain.testConnection(config.providerType.name, config.apiKey, config.baseUrl, config.model)
            onResult(result.isSuccess)
        }
    }

    companion object {
        fun factory(app: TechQuickApplication) = object : ViewModelProvider.Factory {
            @Suppress("UNCHECKED_CAST")
            override fun <T : ViewModel> create(modelClass: Class<T>): T = SettingsViewModel(app) as T
        }
    }
}
