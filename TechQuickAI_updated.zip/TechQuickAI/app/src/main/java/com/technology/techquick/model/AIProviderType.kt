package com.technology.techquick.model

/**
 * Every AI provider TechQuick can use as its "brain".
 *
 * GEMINI, OPENAI, GROQ and CLAUDE have first-class native request/response
 * handling. OPENAI_COMPATIBLE covers the large family of free/cheap
 * providers that speak the OpenAI chat-completions wire format
 * (OpenRouter, Together AI, Mistral La Plateforme, Fireworks, DeepSeek,
 * local Ollama, etc.) — the user just supplies a base URL, model name and
 * key, and TechQuick talks to it the same way it talks to OpenAI.
 */
enum class AIProviderType(val displayName: String, val defaultBaseUrl: String, val defaultModel: String) {
    GEMINI("Gemini", "https://generativelanguage.googleapis.com/v1beta", "gemini-2.5-flash"),
    OPENAI("OpenAI", "https://api.openai.com/v1", "gpt-4o-mini"),
    GROQ("Groq", "https://api.groq.com/openai/v1", "openai/gpt-oss-120b"),
    CLAUDE("Claude (Anthropic)", "https://api.anthropic.com/v1", "claude-3-5-haiku-latest"),
    OPENAI_COMPATIBLE(
        "Other (OpenAI-compatible: OpenRouter, Together, Mistral, DeepSeek, Ollama...)",
        "",
        ""
    );

    companion object {
        fun fromName(name: String?): AIProviderType =
            entries.firstOrNull { it.name == name } ?: GEMINI
    }
}
