package com.technology.techquick.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.technology.techquick.MainActivity
import com.technology.techquick.R
import com.technology.techquick.TechQuickApplication
import com.technology.techquick.model.AIAction
import com.technology.techquick.model.ActionResult
import com.technology.techquick.model.ChatMessage
import com.technology.techquick.model.Sender
import com.technology.techquick.voice.SpeechRecognizerManager
import com.technology.techquick.voice.TextToSpeechManager
import com.technology.techquick.voice.VoiceEvent
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch

/**
 * Always-on "Hey TechQuick" listener. Runs as a foreground service so
 * Android lets it keep the mic alive in the background — Android requires
 * a persistent (but minimal/silent) notification for that on every version
 * from 10 onward; there is no way for any app to avoid that, it's an OS
 * privacy rule. Nothing opens on screen and, once this is on, no extra taps
 * are needed to talk to TechQuick.
 *
 * State machine:
 *  - WAITING mode: short recognition loop, only checking whether the wake
 *    phrase was said.
 *  - COMMAND mode: one real listen — whatever is said goes straight to the
 *    AI, no wake phrase needed.
 * After TechQuick finishes speaking a reply it drops straight back into
 * COMMAND mode for a couple of turns (so a back-and-forth conversation
 * doesn't need "Hey TechQuick" again each time), then returns to WAITING if
 * nothing more is said.
 */
class WakeWordService : Service() {

    private lateinit var app: TechQuickApplication
    private lateinit var speech: SpeechRecognizerManager
    private lateinit var tts: TextToSpeechManager
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var loopJob: Job? = null

    @Volatile private var running = false
    @Volatile private var pendingConfirmation: Pair<String, Map<String, String>>? = null

    override fun onCreate() {
        super.onCreate()
        app = application as TechQuickApplication
        speech = SpeechRecognizerManager(this)
        tts = TextToSpeechManager(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())
        if (!running) {
            running = true
            loopWaitingForWakeWord()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        running = false
        loopJob?.cancel()
        scope.cancel()
        tts.shutdown()
        super.onDestroy()
    }

    private fun loopWaitingForWakeWord() {
        loopJob?.cancel()
        loopJob = scope.launch {
            while (running) {
                val heard = listenOnce()
                if (heard != null && containsWakeWord(heard)) {
                    val remainder = stripWakeWord(heard)
                    if (remainder.isNotBlank()) {
                        handleCommand(remainder)
                    } else {
                        loopCommandMode()
                    }
                    return@launch
                }
                delay(250)
            }
        }
    }

    /** After the wake word (or after a spoken reply), listen for the actual command. */
    private fun loopCommandMode() {
        loopJob?.cancel()
        loopJob = scope.launch {
            var quietTurns = 0
            while (running && quietTurns < 2) {
                val heard = listenOnce()
                if (!heard.isNullOrBlank()) {
                    quietTurns = 0
                    handleCommand(heard)
                    return@launch
                } else {
                    quietTurns++
                    delay(200)
                }
            }
            if (running) loopWaitingForWakeWord()
        }
    }

    /** Runs one recognizer session and suspends until it produces a final result or gives up. */
    private suspend fun listenOnce(): String? {
        var result: String? = null
        val done = CompletableDeferred<Unit>()
        speech.listen().onEach { event ->
            when (event) {
                is VoiceEvent.FinalResult -> result = event.text
                VoiceEvent.Done -> if (!done.isCompleted) done.complete(Unit)
                is VoiceEvent.Error -> if (!done.isCompleted) done.complete(Unit)
                else -> {}
            }
        }.launchIn(scope)
        done.await()
        return result
    }

    private fun handleCommand(text: String) {
        val normalized = normalizeWords(text)

        // A confirmation was pending from the previous turn — resolve that first.
        val pending = pendingConfirmation
        if (pending != null) {
            when {
                CONFIRM_WORDS.any { normalized == it || normalized.startsWith("$it ") } -> {
                    pendingConfirmation = null
                    runActionAndRespond(AIAction(pending.first, pending.second))
                    return
                }
                CANCEL_WORDS.any { normalized == it || normalized.startsWith("$it ") } -> {
                    pendingConfirmation = null
                    speakAndResume("Okay, cancelled.")
                    return
                }
            }
        }

        app.conversationRepository.add(ChatMessage(sender = Sender.USER, text = text))
        scope.launch {
            val history = app.conversationRepository.historyForAI().dropLast(1)
            val result = app.aiBrain.process(history, text)
            result.fold(
                onSuccess = { aiResponse ->
                    app.conversationRepository.add(ChatMessage(sender = Sender.ASSISTANT, text = aiResponse.response))

                    val sensitiveAction = aiResponse.actions.firstOrNull {
                        app.actionRegistry.isRegistered(it.type) && app.actionRegistry.isSensitive(it.type)
                    }
                    for (action in aiResponse.actions) {
                        if (!app.actionRegistry.isRegistered(action.type)) continue
                        if (app.actionRegistry.isSensitive(action.type)) continue
                        runActionSilently(action)
                    }

                    if (sensitiveAction != null) {
                        pendingConfirmation = sensitiveAction.type to sensitiveAction.parameters
                        val def = app.actionRegistry.definitionFor(sensitiveAction.type)
                        speakAndResume("${aiResponse.response} ${def?.description ?: "Do this"}? Say yes to confirm.")
                    } else {
                        speakAndResume(aiResponse.response)
                    }
                },
                onFailure = {
                    speakAndResume("I can't reach the AI right now.")
                }
            )
        }
    }

    private suspend fun runActionSilently(action: AIAction) {
        val result = app.actionEngine.execute(action)
        val summary = when (result) {
            is ActionResult.Success -> result.summary
            is ActionResult.Failure -> result.reason
        }
        app.conversationRepository.add(ChatMessage(sender = Sender.ASSISTANT, text = summary))
    }

    private fun runActionAndRespond(action: AIAction) {
        scope.launch {
            val result = app.actionEngine.execute(action)
            val summary = when (result) {
                is ActionResult.Success -> result.summary
                is ActionResult.Failure -> "I couldn't do that. ${result.reason}"
            }
            app.conversationRepository.add(ChatMessage(sender = Sender.ASSISTANT, text = summary))
            speakAndResume(summary)
        }
    }

    /** Speaks [text], then — once speech genuinely finishes — drops back into hands-free command listening. */
    private fun speakAndResume(text: String) {
        if (app.settingsRepository.voiceResponsesEnabled) {
            tts.speakThenRun(text) { loopCommandMode() }
        } else {
            loopCommandMode()
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Hey TechQuick listening", NotificationManager.IMPORTANCE_MIN
            ).apply { setShowBadge(false) }
            nm.createNotificationChannel(channel)
        }
        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent, PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("TechQuick")
            .setContentText("Listening for \"Hey TechQuick\"")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setPriority(NotificationCompat.PRIORITY_MIN)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .build()
    }

    companion object {
        private const val NOTIFICATION_ID = 4821
        private const val CHANNEL_ID = "techquick_wakeword"

        private val CONFIRM_WORDS = setOf(
            "yes", "confirm", "ok", "okay", "sure", "haan", "han", "haanji", "karo", "kar do", "theek hai", "thik hai"
        )
        private val CANCEL_WORDS = setOf(
            "no", "cancel", "stop", "nahi", "nahin", "mat karo", "rehne do"
        )

        /** Ways speech recognition tends to mangle "Hey TechQuick", longest-first so stripping prefers the fullest match. */
        private val WAKE_VARIANTS = listOf(
            "hey techquick", "hey tech quick", "hey teckquick", "hey tech quik",
            "hay techquick", "hi techquick", "he techquick", "a tech quick",
            "techquick", "tech quick"
        )

        fun containsWakeWord(text: String): Boolean {
            val n = normalizeWords(text)
            return WAKE_VARIANTS.any { n.contains(it) }
        }

        fun stripWakeWord(text: String): String {
            val n = normalizeWords(text)
            for (variant in WAKE_VARIANTS.sortedByDescending { it.length }) {
                val idx = n.indexOf(variant)
                if (idx >= 0) {
                    return (n.substring(0, idx) + n.substring(idx + variant.length)).trim()
                }
            }
            return n
        }

        private fun normalizeWords(s: String): String =
            s.lowercase().replace(Regex("[^a-z0-9 ]"), " ").replace(Regex(" +"), " ").trim()

        fun start(context: Context) {
            val intent = Intent(context, WakeWordService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) context.startForegroundService(intent)
            else context.startService(intent)
        }

        fun stop(context: Context) {
            context.stopService(Intent(context, WakeWordService::class.java))
        }
    }
}
