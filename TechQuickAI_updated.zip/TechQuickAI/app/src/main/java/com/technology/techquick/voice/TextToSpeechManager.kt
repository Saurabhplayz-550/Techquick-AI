package com.technology.techquick.voice

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** Speaks TechQuick's responses aloud when voice responses are enabled in Settings. */
class TextToSpeechManager(context: Context) {

    private var tts: TextToSpeech? = null
    private var ready = false

    init {
        tts = TextToSpeech(context) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = Locale.getDefault()
                ready = true
            }
        }
    }

    fun speak(text: String) {
        if (!ready || text.isBlank()) return
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "techquick_utterance")
    }

    /**
     * Speaks [text] and calls [onDone] once speech genuinely finishes (or
     * immediately if there's nothing to say). Used for hands-free mode: the
     * mic reopens right after TechQuick stops talking, no tap needed.
     */
    fun speakThenRun(text: String, onDone: () -> Unit) {
        if (!ready || text.isBlank()) {
            onDone()
            return
        }
        val utteranceId = "techquick_utterance_${System.currentTimeMillis()}"
        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { onDone() }
            @Deprecated("Deprecated in Java", ReplaceWith(""))
            override fun onError(utteranceId: String?) { onDone() }
        })
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, Bundle(), utteranceId)
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.shutdown()
    }
}
