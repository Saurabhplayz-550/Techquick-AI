package com.technology.techquick.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import com.technology.techquick.ui.theme.HudCyan
import com.technology.techquick.ui.theme.HudCyanBright
import com.technology.techquick.ui.theme.HudCyanDim
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/**
 * Animated HUD environment behind the interface. Deliberately more than a
 * flat gradient: a hex grid, PCB-style circuit traces with node points,
 * two large "radar schematic" arcs, scattered twinkling particles, corner
 * brackets, coordinate crosshairs, and small ladder ticks flanking the
 * voice deck — all low-opacity so the orb stays the focal point, but
 * enough of them that the screen doesn't read as empty. Every dynamic
 * element (twinkle, scan line) is derived from ONE shared animated value
 * so we don't multiply independent animation clocks.
 */
@Composable
fun HudBackground(modifier: Modifier = Modifier) {
    val infinite = rememberInfiniteTransition(label = "hudBg")
    val t by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(7000, easing = LinearEasing)), label = "hudClock"
    )

    Canvas(modifier = modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height

        // Ambient haze where the orb sits
        drawCircle(
            brush = Brush.radialGradient(
                listOf(HudCyan.copy(alpha = 0.11f), Color.Transparent),
                center = Offset(w * 0.5f, h * 0.34f),
                radius = w * 0.95f
            ),
            radius = w * 0.95f,
            center = Offset(w * 0.5f, h * 0.34f)
        )

        // --- Large radar-schematic arcs: static, well off to the sides so
        // they read as depth/schematic rather than competing with the orb.
        drawArc(
            color = HudCyanDim.copy(alpha = 0.20f),
            startAngle = 200f, sweepAngle = 100f, useCenter = false,
            style = Stroke(width = 1.2f, cap = StrokeCap.Round),
            topLeft = Offset(-w * 0.55f, -h * 0.12f),
            size = Size(w * 1.15f, w * 1.15f)
        )
        drawArc(
            color = HudCyanDim.copy(alpha = 0.16f),
            startAngle = 20f, sweepAngle = 110f, useCenter = false,
            style = Stroke(width = 1.2f, cap = StrokeCap.Round),
            topLeft = Offset(w * 0.42f, h * 0.55f),
            size = Size(w * 1.05f, w * 1.05f)
        )

        // --- Hex grid
        val hexRadius = 34f
        val hexHeight = hexRadius * 2f
        val hexWidth = hexRadius * 1.732f
        val hexStroke = Stroke(width = 1f, cap = StrokeCap.Round)
        var row = 0
        var y = -hexHeight / 2f
        while (y < h + hexHeight) {
            val xOffset = if (row % 2 == 0) 0f else hexWidth / 2f
            var x = -hexWidth / 2f + xOffset
            while (x < w + hexWidth) {
                val path = Path().apply {
                    for (i in 0..6) {
                        val angle = (PI / 3.0 * i - PI / 6.0).toFloat()
                        val px = x + hexRadius * cos(angle)
                        val py = y + hexRadius * sin(angle)
                        if (i == 0) moveTo(px, py) else lineTo(px, py)
                    }
                }
                drawPath(path, color = HudCyanDim.copy(alpha = 0.07f), style = hexStroke)
                x += hexWidth
            }
            y += hexHeight * 0.75f
            row++
        }

        // --- PCB-style circuit traces with node dots, in the quiet corners
        // away from the orb and widget columns.
        val traceStroke = Stroke(width = 1.4f, cap = StrokeCap.Round, join = StrokeJoin.Round)
        val traces = listOf(
            listOf(Offset(w * 0.05f, h * 0.09f), Offset(w * 0.05f, h * 0.19f), Offset(w * 0.15f, h * 0.19f), Offset(w * 0.15f, h * 0.27f)),
            listOf(Offset(w * 0.95f, h * 0.08f), Offset(w * 0.95f, h * 0.20f), Offset(w * 0.86f, h * 0.20f), Offset(w * 0.86f, h * 0.29f)),
            listOf(Offset(w * 0.05f, h * 0.94f), Offset(w * 0.16f, h * 0.94f), Offset(w * 0.16f, h * 0.85f)),
            listOf(Offset(w * 0.95f, h * 0.93f), Offset(w * 0.84f, h * 0.93f), Offset(w * 0.84f, h * 0.84f))
        )
        traces.forEach { pts ->
            val path = Path().apply {
                moveTo(pts[0].x, pts[0].y)
                for (i in 1 until pts.size) lineTo(pts[i].x, pts[i].y)
            }
            drawPath(path, color = HudCyan.copy(alpha = 0.20f), style = traceStroke)
            pts.forEach { p -> drawCircle(HudCyanBright.copy(alpha = 0.35f), radius = 2.6f, center = p) }
        }

        // --- Coordinate crosshairs: small "+" marks, purely decorative
        val crosshairs = listOf(
            Offset(w * 0.10f, h * 0.44f), Offset(w * 0.90f, h * 0.46f),
            Offset(w * 0.20f, h * 0.68f), Offset(w * 0.80f, h * 0.14f)
        )
        crosshairs.forEach { c ->
            drawLine(HudCyan.copy(alpha = 0.22f), Offset(c.x - 5f, c.y), Offset(c.x + 5f, c.y), 1f)
            drawLine(HudCyan.copy(alpha = 0.22f), Offset(c.x, c.y - 5f), Offset(c.x, c.y + 5f), 1f)
        }

        // --- Ladder ticks flanking the voice deck, echoing the reference's
        // side decorations next to the mic.
        listOf(w * 0.045f, w * 0.955f).forEach { railX ->
            val top = h * 0.66f
            val bottom = h * 0.86f
            drawLine(HudCyanDim.copy(alpha = 0.28f), Offset(railX, top), Offset(railX, bottom), 1f)
            var ry = top
            while (ry < bottom) {
                drawLine(HudCyanDim.copy(alpha = 0.28f), Offset(railX - 4f, ry), Offset(railX + 4f, ry), 1f)
                ry += (bottom - top) / 5f
            }
        }

        // --- Twinkling particles: alpha derived from the single shared
        // clock (different phase/frequency per particle), no extra animations.
        val particles = listOf(
            Offset(w * 0.12f, h * 0.30f), Offset(w * 0.88f, h * 0.33f),
            Offset(w * 0.22f, h * 0.58f), Offset(w * 0.78f, h * 0.60f),
            Offset(w * 0.08f, h * 0.76f), Offset(w * 0.92f, h * 0.72f),
            Offset(w * 0.30f, h * 0.12f), Offset(w * 0.70f, h * 0.10f),
            Offset(w * 0.15f, h * 0.90f), Offset(w * 0.85f, h * 0.88f)
        )
        particles.forEachIndexed { i, p ->
            val phase = i * 0.63f
            val twinkle = 0.25f + 0.30f * (0.5f + 0.5f * sin(2 * PI.toFloat() * t * (1.3f + i % 3) + phase))
            drawCircle(HudCyanBright.copy(alpha = twinkle), radius = 1.8f, center = p)
        }

        // --- Corner brackets
        val cornerLen = w * 0.14f
        drawLine(HudCyan.copy(alpha = 0.22f), Offset(0f, cornerLen), Offset(0f, 0f), 2f)
        drawLine(HudCyan.copy(alpha = 0.22f), Offset(0f, 0f), Offset(cornerLen, 0f), 2f)
        drawLine(HudCyan.copy(alpha = 0.22f), Offset(w, h - cornerLen), Offset(w, h), 2f)
        drawLine(HudCyan.copy(alpha = 0.22f), Offset(w - cornerLen, h), Offset(w, h), 2f)

        // --- Slow scanning line, barely visible — purely ambient motion
        val scanFraction = t * 1.3f - 0.15f
        val scanY = h * scanFraction
        drawRect(
            brush = Brush.verticalGradient(
                listOf(Color.Transparent, HudCyan.copy(alpha = 0.05f), Color.Transparent),
                startY = scanY - 40f, endY = scanY + 40f
            ),
            topLeft = Offset(0f, scanY - 40f),
            size = Size(w, 80f)
        )
    }
}
