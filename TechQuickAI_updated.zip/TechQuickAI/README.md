# TechQuick AI (Android MVP)

Kotlin + Jetpack Compose Android app implementing the TechQuick AI spec:
onboarding + secure API key setup, an animated AI orb, voice/text
conversation UI with action cards, a validated Action Registry/Engine, and
multi-provider AI support (Gemini, OpenAI, Groq, Claude, and any other
free/cheap OpenAI-compatible provider like OpenRouter, Together AI,
Mistral, DeepSeek, or a local Ollama server).

## How to open

1. Open Android Studio (Koala/2024.1+ recommended) → **Open** → select the
   `TechQuickAI` folder.
2. Let Gradle sync (it will download the wrapper automatically the first
   time — no manual setup needed).
3. Run on a device or emulator with **API 26+**.

The `gradlew` script in this project is a placeholder — Android Studio
regenerates the real Gradle wrapper jar on first sync automatically, so you
don't need to run anything from the command line first.

## Architecture

```
USER → VOICE/TEXT → AI BRAIN → INTENT + ACTION JSON → ACTION VALIDATOR
     → ACTION ENGINE → ANDROID → RESULT → AI RESPONSE
```

- `ai/` — `AIBrain` builds the system prompt (personality + strict action
  JSON contract) and calls whichever provider is configured via
  `AIProviderFactory`. Providers: `GeminiProvider`, `ClaudeProvider`, and
  `OpenAICompatibleProvider` (covers OpenAI, Groq, and any other
  OpenAI-wire-format provider — user supplies base URL + model for
  "Other").
- `actions/ActionRegistry.kt` — the only list of actions the AI is allowed
  to request. Unknown action types are always rejected.
- `actions/ActionEngine.kt` + `actions/impl/*` — real Android
  implementations (volume, flashlight, open app, web/YouTube/Play Store
  search, Maps, WhatsApp, dialer/call, calculator, settings, camera,
  gallery).
- `data/SecureStorage.kt` — API keys live only in
  `EncryptedSharedPreferences` (Android Keystore-backed). Never hard-coded,
  never logged.
- `viewmodel/HomeViewModel.kt` — orchestrates the conversation: sends
  messages to `AIBrain` and runs registered actions immediately via
  `ActionEngine`. Calling a contact and sending a WhatsApp message execute
  right away with no confirmation step; only `shutdown_device` still routes
  through an explicit Confirm/Cancel card, since it locks the screen.
- `ui/` — Compose screens/components: onboarding, the animated `AIOrb`,
  conversation bubbles, action cards, settings.

## Notes / things to double check before shipping

- WhatsApp "sending" opens WhatsApp with the message pre-filled via
  `wa.me` — Android does not allow third-party apps to press Send inside
  WhatsApp for you, so TechQuick is honest about that in the UI (it reports
  "ready to send", not "sent").
- Contact lookups use the `READ_CONTACTS` permission; calls use
  `CALL_PHONE`. Both are requested at launch — if denied, those specific
  actions will fail gracefully with a message instead of crashing.
- This build hasn't been compiled with an Android SDK in the sandbox that
  produced it — do a build/sync pass in Android Studio and fix any
  version-specific Compose/Material3 API drift before relying on it.
- Wake-word / background listening is intentionally NOT implemented, per
  the MVP scope — the architecture (separate `AIBrain`/`ActionEngine`
  layers) is structured so that can be added later without a rewrite.
